import flet as ft

from test.imprimer.print_fac import print_file

def on_print_click(e):
    print_file("facture.pdf")  # Fichier généré précédemment

def main(page: ft.Page):
    btn = ft.ElevatedButton(text="Imprimer la facture", on_click=on_print_click)
    page.add(btn)

ft.app(target=main)

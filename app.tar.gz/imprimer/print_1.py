import win32api
import os

def imprimer_pdf(chemin_fichier_pdf):
    # Assure-toi que le fichier PDF existe
    if not os.path.exists(chemin_fichier_pdf):
        print(f"Le fichier {chemin_fichier_pdf} n'existe pas.")
        return
    
    # Imprimer le fichier PDF en utilisant win32api
    try:
        win32api.ShellExecute(
            0,
            "print",
            chemin_fichier_pdf,
            None,
            ".",
            0
        )
        print("Impression lancée avec succès.")
    except Exception as e:
        print(f"Erreur lors de l'impression: {e}")

# Exemple d'utilisation
chemin_fichier_pdf = r"C:\Users\User\Documents\Project\suiviDeCaisse\test\imprimer\invoice.pdf"
imprimer_pdf(chemin_fichier_pdf)

# Remplacez 'mon_fichier.pdf' par le chemin complet de votre fichier PDF
#imprimer_pdf("C:\\Users\\User\\Documents\\Project\\suiviDeCaisse\\test\\imprimer\\invoice.pdf")
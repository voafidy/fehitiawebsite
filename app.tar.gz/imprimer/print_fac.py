import win32api
import win32print
import os
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import flet as ft

# Fonction pour imprimer un fichier
def print_file(file_path):
    try:
        # Chemin de l'imprimante par défaut
        printer_name = win32print.GetDefaultPrinter()
        print(f"Imprimante par défaut : {printer_name}")

        # Vérification si le fichier existe
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Le fichier {file_path} n'existe pas.")

        # Lancer l'impression avec ShellExecute
        win32api.ShellExecute(
            0,
            "print",
            file_path,
            None,
            ".",
            0
        )
    except Exception as e:
        print(f"Erreur : {e}")

# Fonction pour générer le fichier PDF
def create_pdf(file_path):
    c = canvas.Canvas(file_path, pagesize=letter)
    c.drawString(100, 750, "Facture")
    c.drawString(100, 730, "Date: 21-08-2024")
    c.drawString(100, 710, "Produit: Exemple")
    c.drawString(100, 690, "Prix: 1000")
    c.save()

# Créer le PDF et enregistrer à un chemin absolu
pdf_file_path = os.path.abspath("facture.pdf")
create_pdf(pdf_file_path)

# Fonction déclenchée par le clic du bouton d'impression
def on_print_click(e):
    print_file(pdf_file_path)  # Fichier généré précédemment

# Interface Flet
def main(page: ft.Page):
    btn = ft.ElevatedButton(text="Imprimer la facture", on_click=on_print_click)
    page.add(btn)

ft.app(target=main)

from flet import *
 
 
 
def main(page:Page):
	page.vertical_alignment="center"
	page.horizontal_alignment="center"
 
 
 
	isLogin = Text("Login",
		weight="bold",
		color="white",
		size=20,
 
		# ANIMATION THIS
		offset=transform.Offset(0,0),
		animate_offset=animation.Animation(duration=300)
 
		)
 
 
 
	# LOGIC BUTTON REGISTER
 
	def ganti(e):
		# ANIMATION THE CTX CONTIANER WIDGET
		ctx.bgcolor = "blue" if isLogin.value == "Login" else "red"
		ctx.height = 500 if isLogin.value == "Login" else 150
		ctx.width = 300 if isLogin.value == "Login" else 200
		ctx.border_radius = 0 if isLogin.value == "Login" else 100
 
		print(isLogin.value)
 
		# ISLOGIN ANIMATION
		isLogin.value = "Register"  if isLogin.value == "Login" else "Login"
		isLogin.offset = transform.Offset(5,0)  if isLogin.value == "Login" else transform.Offset(0,0) 
 
 
		# REGISTER ANIMATION BUTTON HIDE AND SHOW
		register_btn.value = "Register" if isLogin.value == "Login" else "Login"
		register_btn.offset = transform.Offset(0,0) if isLogin.value == "Login" else transform.Offset(5,0)
 
 
		# SHOW HIDE YOU REGISTER FORM HERE 
		txt_box_register.visible = True if isLogin.value == "Register" else False
 
 
		page.update()
 
 
	# FORM REGISTER
 
	txt_box_register = Container(
		content=Column([
			TextField(label="Username",
				border_color="white",
				color="white"
				),
			TextField(label="Password",
				border_color="white",
				color="white"
				),
			# LOGIN BUTTON HERE
			ElevatedButton("Login",
				# FULL WIDTH BUTTON
				width=page.window_width,
				on_click=ganti
 
				)
 
			])
 
		)
 
	# SET REGISTER FORM IS HIDDEN 
	txt_box_register.visible = False
 
	# REGISTER BUTTON 
	register_btn = ElevatedButton("Register",
		on_click=ganti,
		# ANIMATION THIS
		offset=transform.Offset(0,0),
		animate_offset=animation.Animation(duration=300)
 
		)
 
	ctx = Container(
		bgcolor="red",
		border_radius=100,
		padding=20,
		width=200,
		alignment=alignment.center,
		height=150,
		animate=animation.Animation(duration=300,curve="easeInOut"),
		content=Column([
			isLogin,
			txt_box_register,
			register_btn
 
 
			])
 
		)
 
 
	page.add(
		ctx
 
		)
app(target=main)
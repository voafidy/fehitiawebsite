from flet import *

def main(page: Page):
    page.title = "CupertinoNavigationBar Example"

    navigation_bar = CupertinoNavigationBar(
        bgcolor=colors.AMBER_50,
        inactive_color=colors.GREY,
        active_color=colors.BLACK,
        on_change=lambda e: print("Selected tab:", e.control.selected_index),
        destinations=[
            NavigationBarDestination(icon=icons.EXPLORE, label="Explore"),
            NavigationBarDestination(icon=icons.COMMUTE, label="Commute"),
            NavigationBarDestination(
                icon=icons.BOOKMARK_BORDER,
                selected_icon=icons.BOOKMARK,
                label="Explore",
            ),
        ]
    )

    # Use a Column to stack the navigation bar and the body
    content = Column(
        controls=[
            navigation_bar,
            Container(
                content=Column(
                    scroll='auto',
                    controls=[
                        Container(
                            height=50,
                            width=500,
                            bgcolor=colors.GREEN_100,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN_200,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN_300,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN_400,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN_500,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN_600,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN_700,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN_800,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN_900,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN_50,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN_ACCENT,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN_ACCENT_100,
                                content=Column(
                                controls=[Text(f"GREEN_ACCENT_100 ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN_ACCENT_200,
                                content=Column(
                                controls=[Text(f"GREEN_ACCENT_200 ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN_ACCENT_700,
                                content=Column(
                                controls=[Text(f"GREEN_ACCENT_700 ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN_ACCENT_400,
                                content=Column(
                                controls=[Text(f"GREEN_ACCENT_400 ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.LIGHT_GREEN_500,
                                content=Column(
                                controls=[Text(f"LIGHT_GREEN_500 ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.LIGHT_GREEN_600,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.LIGHT_GREEN_700,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        Container(
                            height=50,
                            width=1030,
                            bgcolor=colors.GREEN,
                                content=Column(
                                controls=[Text(f"Tarif ", size=16,weight='bold'),]
                            )
                        ),
                        
                    ]
                ),
                alignment=alignment.center,
                expand=True,
            ),
        ],
        expand=True,
    )

    page.add(content)

app(target=main)













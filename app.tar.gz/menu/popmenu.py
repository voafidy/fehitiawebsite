import flet as ft

def main(page: ft.Page):
    def on_menu_item_click(e):
        page.dialog = ft.AlertDialog(title=ft.Text(f"Vous avez cliqué sur: {e.control.content.text}"))
        page.dialog.open = True
        page.update()

    # Créez des éléments de menu avec icônes et labels
    menu_items = [
        ft.PopupMenuItem(
            content=ft.Row([ft.Icon(ft.icons.HOME), ft.Text("Accueil")]),
            on_click=on_menu_item_click
        ),
        ft.PopupMenuItem(
            content=ft.Row([ft.Icon(ft.icons.SETTINGS), ft.Text("Paramètres")]),
            on_click=on_menu_item_click
        ),
        ft.PopupMenuItem(
            content=ft.Row([ft.Icon(ft.icons.EXIT_TO_APP), ft.Text("Quitter")]),
            on_click=on_menu_item_click
        ),
    ]

    # Créez le bouton de menu contextuel avec icône et étiquette
    popup_menu_button = ft.PopupMenuButton(
        icon=ft.icons.MORE_VERT,
        content=ft.Text("Options"),
        items=menu_items
    )

    # Ajoutez le bouton à la page
    page.add(popup_menu_button)

# Démarrez l'application
ft.app(target=main)

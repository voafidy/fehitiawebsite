"""Caisse :

Icon(icons.PAYMENT)
Icon(icons.ACCOUNT_BALANCE_WALLET)
Icon(icons.MONEY)
Journal de compte :

Icon(icons.BOOK)
Icon(icons.INSERT_DRIVE_FILE)
Icon(icons.DESCRIPTION)
Suivi :

Icon(icons.TRACK_CHANGES)
Icon(icons.ASSESSMENT)
Icon(icons.QUERY_STATS)"""